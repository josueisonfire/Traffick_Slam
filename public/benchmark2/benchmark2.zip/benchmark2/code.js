var game = new Phaser.Game(1200, 600, Phaser.CANVAS, 'phaser-example', { preload: preload, create: create, update: update});

function preload()
{
    // preload assets
    game.load.image('menu_background', 'assets/menu_background.png');
    game.load.image('menu_button','assets/menu_button.png')
    game.load.image('menu_car','assets/menu_car.png')
}

// declare global variables

function create()
{
    //main function to create main page.
    displayMainMenu();
}

function update()
{
    //update function
}

// function to display main menu.
function displayMainMenu()
{
    //load image
    game.add.sprite(0,0,'menu_background');
    var newgame_button = game.add.sprite(600,50,'menu_button');
    var controls_button = game.add.sprite(600,225,'menu_button');
    var help_button = game.add.sprite(600,400,'menu_button');
    var car = game.add.sprite(85,200,'menu_car');
    car.scale.setTo(0.7,0.7);

    var text_newgame = addtext(875,125,'NEW GAME');
    var text_controls = addtext(875,300,'CONTROLS');
    var text_help = addtext(875,475,'HELP');
    var text_title1 = addtext(309,150,'TRAFFIC');
    var text_title2 = addtext(309,274,'SLAM');
}

function addtext(x, y, str)
{
    var text = game.add.text(x,y,str);
    text.anchor.set(0.5);
    text.font = 'Arial Black';
    text.fontSize = 50;
    text.fontWeight = 'bold';
    text.fill = '#ffffff';
    text.setShadow(0, 0, 'rgba(0, 0, 0, 0.5)', 0);
    return text;
}